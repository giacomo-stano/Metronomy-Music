import { request, type Song } from './api';

const cache = new Map<string, Song[]>();
const pending = new Map<string, Promise<Song[]>>();

export function peekAlbumSongs(albumId: string): Song[] | undefined {
  return cache.get(albumId);
}

export function preloadAlbumSongs(
  albumId: string,
  force = false
): Promise<Song[]> {
  if (!force) {
    const cached = cache.get(albumId);
    if (cached) return Promise.resolve(cached);

    const running = pending.get(albumId);
    if (running) return running;
  }

  const promise = request<{ songs: Song[] }>(
    'albums/' + encodeURIComponent(albumId)
  )
    .then(data => {
      const songs = Array.isArray(data.songs) ? data.songs : [];
      cache.set(albumId, songs);
      return songs;
    })
    .finally(() => {
      if (pending.get(albumId) === promise) {
        pending.delete(albumId);
      }
    });

  pending.set(albumId, promise);
  return promise;
}

export function clearAlbumSongsCache() {
  cache.clear();
  pending.clear();
}
