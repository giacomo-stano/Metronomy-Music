import { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, SafeAreaView, ScrollView, Text, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { login, type Account } from './api';
import { useTheme } from './theme';
import { offlineProfiles, offlineAccount, type OfflineProfile } from './offlineProfiles';
import Pressable from './SpringPressable';

export default function LoginScreen({ onLogin }: { onLogin: (account: Account) => void }) {
  const { colors: c } = useTheme();
  const [url, setURL] = useState(process.env.EXPO_PUBLIC_AURORA_BASE_URL || 'http://192.168.1.24:8180');
  const [username, setUsername] = useState(''); const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const [profiles, setProfiles] = useState<OfflineProfile[]>([]);
  const [checking, setChecking] = useState(true);
  useEffect(() => { let active = true; offlineProfiles().then(values => { if (active) setProfiles(values); }).finally(() => { if (active) setChecking(false); }).catch(() => {}); return () => { active = false; }; }, []);
  const field = { color: c.text, backgroundColor: c.surface, borderRadius: 16, padding: 16, fontSize: 17, marginTop: 10 };
  async function submit() {
    if (busy) return; setBusy(true); setError('');
    try { const result = await login(url, username, password); setPassword(''); onLogin(result); }
    catch (e) { setError(e instanceof Error ? e.message : 'Connessione non riuscita.'); }
    finally { setBusy(false); }
  }
  function confirm() {
    if (url.trim().toLowerCase().startsWith('http:')) Alert.alert('Connessione non cifrata', 'Usa HTTP soltanto sulla rete domestica fidata o in VPN: le credenziali viaggiano senza cifratura. Per accessi esterni usa HTTPS.', [{ text: 'Annulla', style: 'cancel' }, { text: 'Accedi sulla rete fidata', onPress: () => void submit() }]);
    else void submit();
  }
  return <SafeAreaView style={{ flex: 1, backgroundColor: c.background }}><KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}><ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 28, paddingTop: 60 }}>
    <Ionicons name="musical-notes" size={52} color={c.accent} /><Text style={{ color: c.text, fontSize: 36, fontWeight: '800', marginTop: 20 }}>Aurora Music</Text>
    <Text style={{ color: c.secondary, fontSize: 17, lineHeight: 24, marginVertical: 16 }}>La tua musica, il tuo account.</Text>
    {checking && <Text style={{ color: c.secondary, marginBottom: 16 }}>Verifica musica scaricata…</Text>}
    {!!profiles.length && <View style={{ backgroundColor: c.surface, borderRadius: 20, padding: 18, marginBottom: 24 }}><Text style={{ color: c.text, fontWeight: '700', fontSize: 21 }}>Ascolta offline</Text>{profiles.map(profile => <Pressable key={profile.baseURL + profile.username} disabled={busy} onPress={() => onLogin(offlineAccount(profile))} style={{ paddingVertical: 16 }} accessibilityRole="button"><Text style={{ color: c.accent, fontSize: 17 }}>{profile.username} · {profile.count} brani sull’iPhone</Text><Text numberOfLines={1} style={{ color: c.secondary, fontSize: 12, marginTop: 4 }}>{profile.baseURL}</Text></Pressable>)}<Text style={{ color: c.secondary, fontSize: 12 }}>Apre solo le copie su questo dispositivo, senza login al server. Chi può sbloccare l’iPhone può accedere a questi contenuti.</Text></View>}
    <Text style={{ color: c.secondary }}>URL server Aurora (bridge, non porta Navidrome 4533)</Text>
    <TextInput accessibilityLabel="URL server Aurora" editable={!busy} style={field} value={url} onChangeText={setURL} keyboardType="url" autoCapitalize="none" autoCorrect={false} />
    <TextInput accessibilityLabel="Utente Navidrome" editable={!busy} style={field} placeholder="Utente Navidrome" placeholderTextColor={c.secondary} value={username} onChangeText={setUsername} textContentType="username" autoCapitalize="none" autoCorrect={false} />
    <TextInput accessibilityLabel="Password Navidrome" editable={!busy} style={field} placeholder="Password Navidrome" placeholderTextColor={c.secondary} value={password} onChangeText={setPassword} textContentType="password" secureTextEntry returnKeyType="go" onSubmitEditing={confirm} />
    {!!error && <Text accessibilityLiveRegion="polite" style={{ color: c.accent, marginTop: 16 }}>{error}</Text>}
    <Pressable accessibilityRole="button" disabled={busy || !username.trim() || !password} onPress={confirm} style={{ backgroundColor: c.accent, borderRadius: 18, alignItems: 'center', padding: 18, marginTop: 24, opacity: busy || !username.trim() || !password ? 0.5 : 1 }}>{busy ? <ActivityIndicator color="#fff" /> : <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700' }}>Accedi</Text>}</Pressable>
    <View style={{ marginTop: 24 }}><Text style={{ color: c.secondary, lineHeight: 21 }}>La password non viene salvata nell’app. Alla riapertura o dopo il riavvio del bridge dovrai accedere di nuovo. Download e file sono gestiti secondo le autorizzazioni del tuo account.</Text></View>
  </ScrollView></KeyboardAvoidingView></SafeAreaView>;
}
